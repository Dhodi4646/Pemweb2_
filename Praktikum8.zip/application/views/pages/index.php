    <!-- Content Wrapper. Contains page content --> 
    <div class="content-wrapper">
        <!-- Main content -->
        <section class="content">
            <div class="card-body utama font-weight-bold text-center border m-2">
                <h1 class="pesan">
                    Welcome to WebAdmin 2.0!!
                </h1>
                <h4 class="pesan">
                    Develop By <a href="#" style="color: pink;"><i>DhodiYogaSahida</i></a> &copy;2022
                </h4>
            </div>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
</div>